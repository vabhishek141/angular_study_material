var logger = 
    require("sunbeamloggerbymahesh");
logger.SayHi()