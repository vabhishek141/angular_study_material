
class Test
{
    // no=10;
    // name = "Mahesh";

    no;
    name;

    constructor(num, nm)
    {
        // console.log("Inside constructor");
        // console.log(num);
        // console.log(nm)

         this.no = num;
         this.name = nm ;
    }

    Print()
    {
        console.log(this.no + this.name);
    }
}

//var obj1 = new Test("7", "Bond");
// obj1.name = "gr 8 Mahesh";
// obj1.no = "kuchbhi";

//obj1.Print();




