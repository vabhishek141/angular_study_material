import { Emp } from './Emp'

var obj = new   Emp();
obj.Name = "ABCD";
var result=  obj.PrintDetails();

console.log(result);
