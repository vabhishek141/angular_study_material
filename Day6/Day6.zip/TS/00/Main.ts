
import { Maths} from './Maths'

var obj = new Maths();
var result= obj.Add(10,20);
console.log(result)




















// function Print()
// {
//     console.log("Hello TS .. is JS");
// }

// Print();