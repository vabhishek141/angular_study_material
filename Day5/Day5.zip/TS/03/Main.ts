import {Emp} from './Emp'
import {Person} from './Person'


// var obj = new Emp(10,"MP","Pune");
//var obj = new Emp(10,"MP");
var obj = new Person(10);

var result =  obj.GetDetails();
// console.log(result);

alert(result);



