
//Importing Logger Class
//---------------------------------------
// var Logger= require("./logger");

// var obj = new Logger();
// obj.Log("hello");



//Importing Function from Logger.js
//---------------------------------------

//  var SayHi = require("./logger");

//  SayHi("mahesh");




///Use GetSomeObject function 
// which is factory function 
// which returns Logger Obejct

// var GetSomeObejct = require("./logger");
// var objOfLogger= GetSomeObejct();
// objOfLogger.Log("some message");





























